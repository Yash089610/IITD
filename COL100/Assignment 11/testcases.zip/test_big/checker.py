import os
import sys
import time

st = time.time()
for i in range(1, 11):
    start = time.time()
    os.system(f"a.exe < input_{i}.txt > {i}_test.txt")
    end = time.time()
    print(i, end-start)
    s1 = "output_" + str(i) + ".txt"
    s2 = str(i) + "_test.txt"
    with open(os.path.join(sys.path[0], s1), "r") as f:
        lines = f.readlines()

    with open(os.path.join(sys.path[0], s2), "r") as f:
        lines_check = f.readlines()

    if(len(lines) == len(lines_check)):
        # print("Lines match")
        counter = len(lines)
    else:
        print(f"Lines donot match for {i}")
        exit()

    condition = 1
    lines_with_error = []
    for c in range(counter):
        if(lines[c] == lines_check[c]):
            continue
        else:
            n = len(lines[c])
            m = len(lines_check[c])
            if(m+1 == n or n+1 == m):
                continue
            lines_with_error.append(c)
            condition = 0

    if(condition != 1):
        print(i, f" Testcase failed {i}")
        # for i in range(len(lines_with_error)):
        #     print(lines_with_error)
print("Total Time:", time.time()-st)
