from a1 import findPositionandDistance
f = open("check.txt", "w")
m = 1
for i in open("testcases.txt", "r"):
    f.write(str(findPositionandDistance(str(i)))+"\n")
    print(f"Testcase result {m} generated")
    m += 1

for i in open("testcases_big.txt", "r"):
    f.write(str(findPositionandDistance(str(i)))+"\n")
    print(f"Testcase result {m} generated")
    m += 1
