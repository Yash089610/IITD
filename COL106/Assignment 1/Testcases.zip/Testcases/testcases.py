import random

size = 100
# size = 100
x, y = 0, 0
f = open("input.txt", "w")
l = []
for m in range(size):
    s = ""
    for i in range(100):
        a = random.randint(1, 3)
        if a == 1:
            for i in range(random.randint(50, 100)):
                b = random.randint(1, 2)
                if b == 1:
                    s += "+"
                if b == 2:
                    s += "-"
                b = random.randint(1, 3)
                if b == 1:
                    s += "X"
                if b == 2:
                    s += "Y"
                if b == 3:
                    s += "Z"

        if a == 2:
            s += str(random.randint(1, 1000000000))
            s += "("
            for i in range(random.randint(50, 100)):
                # for i in range(random.randint(50, 500)):
                b = random.randint(1, 2)
                if b == 1:
                    s += "+"
                if b == 2:
                    s += "-"
                b = random.randint(1, 3)
                if b == 1:
                    s += "X"
                if b == 2:
                    s += "Y"
                if b == 3:
                    s += "Z"
            s += ")"

        if a == 3:
            for i in range(random.randint(10, 1000)):
                # for i in range(random.randint(10, 100)):
                x += 1
                s += str(random.randint(100, 1000000000))
                s += "("
                b = random.randint(1, 2)
                if b == 1:
                    for i in range(random.randint(50, 100)):
                        # for i in range(random.randint(50, 500)):
                        b = random.randint(1, 2)
                        if b == 1:
                            s += "+"
                        if b == 2:
                            s += "-"
                        b = random.randint(1, 3)
                        if b == 1:
                            s += "X"
                        if b == 2:
                            s += "Y"
                        if b == 3:
                            s += "Z"
                    s += ")"
                    y += 1
            s += ")"*(x-y)
            y = x
    print(f"Testcase {m} generated")
    s += "\n"
    f.write(s)
