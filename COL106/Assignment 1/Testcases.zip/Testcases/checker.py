import time
from a1 import findPositionandDistance
r = list(map(lambda x: x.rstrip(), open("check.txt", "r").readlines()))
tn = open("testcases.txt", "r").readlines()
rt = []
tb = open("testcases_big.txt", "r").readlines()

print("Starting Checker")
st = time.time()
findPositionandDistance("+Y3(+X+Y+Z)")
print(f"Time taken for Function Test is {time.time()-st}")
print()
print("Testing normal testcases.")
st = time.time()
for i in tn:
    rt.append(str(findPositionandDistance(str(i).replace("\n", ""))))
print(f"Time taken for normal testcases is {time.time()-st}")
print()
print("Checking Big Testcases")
st = time.time()
for i in tb:
    rt.append(str(findPositionandDistance(str(i).replace("\n", ""))))
print(f"Time taken for big testcases is {time.time()-st}")
print()
print("All cases passed" if rt == r else "Your code didnt pass all testcases.")
